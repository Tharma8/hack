
import React from 'react';
import { Camera, Cpu, Globe, Search } from 'lucide-react';

const IMAGES = [
  {
    url: "https://images.unsplash.com/photo-1558494949-ef010cbdcc4b?auto=format&fit=crop&w=800&q=80",
    label: "Data Center Analysis",
    description: "Deep packet inspection for origin tracking."
  },
  {
    url: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80",
    label: "Mobile Forensics",
    description: "Secure imaging of compromised devices."
  },
  {
    url: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80",
    label: "Incident Response",
    description: "Human-in-the-loop strategy meetings."
  }
];

const ForensicLab: React.FC = () => {
  return (
    <section className="py-24 bg-slate-950/50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="p-3 bg-blue-500/10 rounded-2xl w-fit text-blue-400 border border-blue-500/20">
              <Cpu className="w-6 h-6" />
            </div>
            <h2 className="font-sora text-4xl font-bold">The Core of Our <br/><span className="text-teal-400">Investigative Power.</span></h2>
            <p className="text-slate-400 text-lg leading-relaxed">
              We maintain a state-of-the-art forensic laboratory capable of tracking complex multi-chain transactions and unmasking obfuscated digital identities.
            </p>
            <div className="grid grid-cols-2 gap-6 pt-4">
              <div className="glass p-6 rounded-3xl border-white/5 space-y-2">
                <Globe className="w-5 h-5 text-teal-400" />
                <h4 className="font-bold">Global Jurisdictions</h4>
                <p className="text-xs text-slate-500">Coordination with 140+ international law enforcement nodes.</p>
              </div>
              <div className="glass p-6 rounded-3xl border-white/5 space-y-2">
                <Search className="w-5 h-5 text-teal-400" />
                <h4 className="font-bold">OSINT Maturity</h4>
                <p className="text-xs text-slate-500">Proprietary scrapers for dark-web forum monitoring.</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="group relative overflow-hidden rounded-[2rem] aspect-[3/4] border border-white/10">
                <img src={IMAGES[0].url} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-70" alt="Lab" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6">
                  <p className="text-xs font-bold text-teal-400 uppercase mb-1">{IMAGES[0].label}</p>
                  <p className="text-[10px] text-slate-400 leading-tight">{IMAGES[0].description}</p>
                </div>
              </div>
            </div>
            <div className="space-y-4 pt-12">
              {IMAGES.slice(1).map((img, i) => (
                <div key={i} className="group relative overflow-hidden rounded-[2rem] aspect-[3/4] border border-white/10">
                  <img src={img.url} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-70" alt="Lab" />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
                  <div className="absolute bottom-6 left-6 right-6">
                    <p className="text-xs font-bold text-teal-400 uppercase mb-1">{img.label}</p>
                    <p className="text-[10px] text-slate-400 leading-tight">{img.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ForensicLab;
