
import React from 'react';
import { LayoutDashboard, Clock, FileText, Activity, ShieldCheck, Map, ArrowUpRight, Lock } from 'lucide-react';

const CasePortal: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#0a0a0c] pt-28 px-6 pb-12">
      <div className="max-w-7xl mx-auto space-y-8">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
          <div>
            <div className="flex items-center gap-2 text-teal-400 text-xs font-bold uppercase tracking-widest mb-1">
              <Lock className="w-4 h-4" /> Secure Portal Session
            </div>
            <h1 className="text-4xl font-sora font-bold">Investigator Dashboard</h1>
          </div>
          <div className="flex gap-3">
            <button className="px-6 py-2 rounded-xl glass text-xs font-bold uppercase tracking-widest hover:bg-white/10 transition-all">Download All Data</button>
            <button className="px-6 py-2 rounded-xl bg-red-500/10 text-red-400 text-xs font-bold uppercase tracking-widest border border-red-500/20">Emergency Lock</button>
          </div>
        </header>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Bento Stats */}
          <div className="lg:col-span-1 space-y-6">
            <div className="glass p-8 rounded-[2rem] border-white/5 space-y-2">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Active Cases</p>
              <p className="text-4xl font-sora font-bold">01</p>
            </div>
            <div className="glass p-8 rounded-[2rem] border-white/5 space-y-2">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Investigation Hours</p>
              <p className="text-4xl font-sora font-bold">142</p>
            </div>
            <div className="glass p-8 rounded-[2rem] border-teal-500/20 bg-teal-500/[0.02] space-y-2">
              <p className="text-xs font-bold text-teal-400 uppercase tracking-widest">Recovery Success</p>
              <p className="text-4xl font-sora font-bold text-teal-400">94%</p>
            </div>
          </div>

          {/* Main Case Track */}
          <div className="lg:col-span-3 space-y-6">
            <div className="glass p-8 rounded-[2.5rem] border-white/5 overflow-hidden relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-teal-500/10 blur-3xl" />
              
              <div className="flex justify-between items-start mb-8">
                <div className="space-y-1">
                  <h3 className="text-2xl font-bold">#HK-2024-811-A</h3>
                  <p className="text-slate-400 text-sm">Crypto Asset Tracing - Ethereum Network</p>
                </div>
                <span className="px-4 py-1 rounded-full bg-teal-500/20 text-teal-400 text-[10px] font-bold uppercase tracking-widest border border-teal-500/20">
                  In Progress: 75%
                </span>
              </div>

              {/* Progress Bar */}
              <div className="h-2 w-full bg-slate-800 rounded-full mb-12 relative">
                <div className="absolute top-0 left-0 h-full bg-teal-500 rounded-full shadow-[0_0_15px_rgba(45,212,191,0.5)]" style={{ width: '75%' }} />
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                <div className="space-y-4">
                  <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                    <Map className="w-3 h-3" /> Latest Milestone
                  </h4>
                  <p className="text-sm font-bold">KYC Entity Identified</p>
                  <p className="text-xs text-slate-400">Funds traced to Binance-affiliated off-ramp in Estonia.</p>
                </div>
                <div className="space-y-4">
                  <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                    <ShieldCheck className="w-3 h-3" /> Verification
                  </h4>
                  <p className="text-sm font-bold">On-chain Auth Complete</p>
                  <p className="text-xs text-slate-400">Signature matched against original incident report.</p>
                </div>
                <div className="space-y-4">
                  <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                    <Activity className="w-3 h-3" /> Status
                  </h4>
                  <p className="text-sm font-bold">Freeze Order Drafted</p>
                  <p className="text-xs text-slate-400">Preparing legal brief for Interpol coordination.</p>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="glass p-8 rounded-[2rem] border-white/5 space-y-6">
                <h3 className="text-xl font-bold">Timeline Logs</h3>
                <div className="space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex gap-4 items-start border-b border-white/5 pb-4 last:border-0">
                      <div className="w-2 h-2 rounded-full bg-teal-500 mt-2 shadow-[0_0_5px_teal]" />
                      <div>
                        <p className="text-xs font-bold">Oct 2{i}, 2024 - 14:2{i}</p>
                        <p className="text-sm text-slate-400">Forensic node processed wallet 0x3a...{i}f2</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="glass p-8 rounded-[2rem] border-white/5 flex flex-col items-center justify-center text-center space-y-4">
                <div className="p-4 bg-teal-500/10 rounded-full text-teal-400">
                  <FileText className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold">Evidence Folder</h3>
                <p className="text-sm text-slate-500">12 Files encrypted and secured.</p>
                <button className="px-6 py-2 bg-white/5 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-white/10">Manage Files</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CasePortal;
