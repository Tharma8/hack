
import React from 'react';
import { ExtendedFeature } from '../constants';
import { ChevronLeft, ShieldCheck, ArrowRight, Activity, MessageCircle, Lock } from 'lucide-react';

interface FeatureDetailProps {
  feature: ExtendedFeature;
  onBack: () => void;
  onStartIntake: () => void;
}

const FeatureDetail: React.FC<FeatureDetailProps> = ({ feature, onBack, onStartIntake }) => {
  const whatsappUrl = `https://wa.me/1234567890?text=${encodeURIComponent(feature.whatsappContext)}`;

  return (
    <div className="pt-28 pb-20 px-6 min-h-screen bg-[#0a0a0c]">
      <div className="max-w-6xl mx-auto space-y-12">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-slate-500 hover:text-teal-400 transition-colors font-bold uppercase tracking-widest text-xs"
        >
          <ChevronLeft className="w-4 h-4" /> Back to Intelligence Dashboard
        </button>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 animate-in fade-in slide-in-from-left-8 duration-700">
            <div className="inline-flex items-center gap-3 px-4 py-2 rounded-2xl glass border-teal-500/20 text-teal-400">
              {feature.icon}
              <span className="font-bold text-sm uppercase tracking-widest">{feature.category} Protocols</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-sora font-bold leading-tight">
              {feature.title} <span className="text-teal-400">Unit</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed">
              {feature.longDescription}
            </p>
            
            <div className="space-y-4">
              <h3 className="font-bold text-white uppercase tracking-widest text-xs flex items-center gap-2">
                <Activity className="w-4 h-4 text-teal-400" /> Forensic Steps Required
              </h3>
              <div className="grid gap-4">
                {feature.methodology.map((m, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 glass rounded-2xl border-white/5 group hover:border-teal-500/30 transition-all">
                    <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-teal-400 font-bold border border-white/5 group-hover:border-teal-500/30">
                      0{i + 1}
                    </div>
                    <span className="text-slate-300 font-semibold">{m}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-6 flex flex-col sm:flex-row gap-4">
              <a 
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-10 py-5 rounded-2xl bg-teal-500 text-slate-900 font-black flex items-center justify-center gap-3 hover:scale-105 transition-transform shadow-xl shadow-teal-500/30"
              >
                <MessageCircle className="w-5 h-5" /> Chat with Agent Now
              </a>
              <button 
                onClick={onStartIntake}
                className="px-10 py-5 rounded-2xl glass font-bold hover:bg-white/10 transition-colors border border-white/10 flex items-center justify-center gap-3"
              >
                Log Case Details <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="relative animate-in fade-in zoom-in duration-1000">
             <div className="absolute inset-0 bg-teal-500/10 blur-[120px] rounded-full"></div>
             <div className="relative glass rounded-[3rem] p-4 border-white/5 overflow-hidden shadow-2xl">
               <img 
                 src={feature.image} 
                 className="w-full h-[550px] object-cover rounded-[2.5rem] grayscale hover:grayscale-0 transition-all duration-700 opacity-60 hover:opacity-100"
                 alt={feature.title} 
               />
               <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
               <div className="absolute bottom-8 left-8 right-8 p-8 glass rounded-3xl border-teal-500/20 bg-slate-950/40">
                 <div className="flex items-center justify-between mb-4">
                   <div className="flex items-center gap-4">
                     <div className="p-3 bg-teal-400/20 rounded-xl">
                       <ShieldCheck className="w-6 h-6 text-teal-400" />
                     </div>
                     <h4 className="font-sora font-bold text-xl uppercase tracking-tighter">Verified Protocol</h4>
                   </div>
                   <div className="flex items-center gap-2 text-xs font-bold text-teal-400/60">
                     <Lock className="w-3 h-3" /> End-to-End Encrypted
                   </div>
                 </div>
                 <p className="text-sm text-slate-400 leading-relaxed mb-6">
                   This forensic unit has a 96% identification rate for {feature.title.toLowerCase()}. Immediate intervention significantly increases recovery probability.
                 </p>
                 <a 
                    href={whatsappUrl}
                    className="w-full py-4 glass border-teal-500/30 rounded-xl text-teal-400 font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-2 hover:bg-teal-500 hover:text-slate-900 transition-all"
                 >
                   Request Priority Hotline Access
                 </a>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeatureDetail;
