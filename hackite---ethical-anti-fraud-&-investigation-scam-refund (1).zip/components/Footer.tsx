
import React from 'react';
import { Shield } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: any) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="py-12 border-t border-white/5 bg-slate-950 px-6">
      <div className="max-w-7xl mx-auto flex flex-col items-center space-y-8">
        <div className="flex items-center gap-2">
          <Shield className="w-6 h-6 text-teal-400" />
          <span className="font-sora text-xl font-bold tracking-tight">HACKITE</span>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center md:text-left">
          <div className="space-y-4">
            <h5 className="font-bold text-sm uppercase tracking-widest text-slate-500">Platform</h5>
            <ul className="text-slate-400 space-y-2 text-sm">
              <li><button onClick={() => onNavigate('home')} className="hover:text-teal-400">Home</button></li>
              <li><button onClick={() => onNavigate('portal')} className="hover:text-teal-400">Case Portal</button></li>
              <li><button onClick={() => onNavigate('intel')} className="hover:text-teal-400">Intelligence</button></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h5 className="font-bold text-sm uppercase tracking-widest text-slate-500">Company</h5>
            <ul className="text-slate-400 space-y-2 text-sm">
              <li><a href="#about" className="hover:text-teal-400">Our Team</a></li>
              <li><a href="#faq" className="hover:text-teal-400">Ethics FAQ</a></li>
              <li><button onClick={() => onNavigate('intake')} className="hover:text-teal-400">Case Intake</button></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h5 className="font-bold text-sm uppercase tracking-widest text-slate-500">Legal</h5>
            <ul className="text-slate-400 space-y-2 text-sm">
              <li><a href="#" className="hover:text-teal-400">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-teal-400">Investigation Terms</a></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h5 className="font-bold text-sm uppercase tracking-widest text-slate-500">Support</h5>
            <ul className="text-slate-400 space-y-2 text-sm">
              <li><a href="#" className="hover:text-teal-400">Help Center</a></li>
              <li><a href="#" className="hover:text-teal-400">API Documentation</a></li>
            </ul>
          </div>
        </div>

        <div className="max-w-2xl text-center text-[10px] text-slate-600 leading-relaxed uppercase tracking-tighter border-t border-white/5 pt-8">
          Disclaimer: Hackite is an educational and ethical investigation assistance platform. We are not a law enforcement agency. We do not provide "hacker-for-hire" services involving unauthorized access. All guidance is for facilitating official reports to authorized institutions.
        </div>

        <div className="text-slate-500 text-xs">
          © {new Date().getFullYear()} Hackite Digital Intelligence. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
