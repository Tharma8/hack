
import React from 'react';
import { FEATURES } from '../constants';
import { ChevronRight } from 'lucide-react';

interface FeatureGridProps {
  onSelectFeature: (id: string) => void;
}

const FeatureGrid: React.FC<FeatureGridProps> = ({ onSelectFeature }) => {
  return (
    <section id="features" className="py-24 bg-slate-900/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 space-y-4">
          <h2 className="font-sora text-4xl font-bold">Expert Solutions</h2>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg">
            From cryptocurrency theft to complex identity fraud, our investigation framework is built on ethical principles and professional forensic techniques.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {FEATURES.map((feature) => (
            <div 
              key={feature.id} 
              className="glass p-10 rounded-[2.5rem] glass-hover transition-all duration-300 group cursor-default border-white/5"
            >
              <div className="mb-8 p-5 rounded-2xl bg-slate-800/50 w-fit group-hover:bg-teal-400/20 transition-colors shadow-inner">
                {feature.icon}
              </div>
              <div className="text-[10px] font-black text-teal-400 uppercase tracking-[0.2em] mb-3">
                {feature.category} Intelligence
              </div>
              <h3 className="font-sora text-2xl font-bold mb-4 group-hover:text-teal-400 transition-colors">{feature.title}</h3>
              <p className="text-slate-400 leading-relaxed mb-8 text-sm">
                {feature.description}
              </p>
              <button 
                onClick={() => onSelectFeature(feature.id)}
                className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-white group-hover:text-teal-400 transition-colors"
              >
                Explore Methodology <ChevronRight className="w-4 h-4 translate-x-0 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeatureGrid;
