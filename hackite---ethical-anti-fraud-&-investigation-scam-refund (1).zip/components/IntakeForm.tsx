
import React, { useState } from 'react';
import { Shield, Send, Wallet, User, FileText, ChevronRight, ChevronLeft, CheckCircle } from 'lucide-react';

const IntakeForm: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);

  const nextStep = () => setStep(s => s + 1);
  const prevStep = () => setStep(s => s - 1);

  if (submitted) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center space-y-6 animate-in fade-in zoom-in duration-500">
        <div className="w-20 h-20 rounded-full bg-teal-500/20 flex items-center justify-center text-teal-400">
          <CheckCircle className="w-12 h-12" />
        </div>
        <h2 className="text-4xl font-sora font-bold">Case Logged Successfully</h2>
        <p className="text-slate-400 max-w-md">Your evidence has been encrypted and assigned to our Lead Forensicist. Case ID: #HK-9921-X</p>
        <button onClick={onBack} className="px-8 py-3 rounded-xl bg-teal-500 text-slate-900 font-bold hover:scale-105 transition-transform">
          Return to Dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto py-12 px-6">
      <div className="mb-12 flex justify-between items-center">
        <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-white transition-colors">
          <ChevronLeft className="w-4 h-4" /> Exit Intake
        </button>
        <div className="flex gap-2">
          {[1, 2, 3].map(i => (
            <div key={i} className={`h-1.5 w-12 rounded-full transition-colors ${step >= i ? 'bg-teal-500' : 'bg-slate-800'}`} />
          ))}
        </div>
      </div>

      <div className="glass p-10 rounded-[3rem] border-white/10 shadow-2xl space-y-8">
        {step === 1 && (
          <div className="space-y-6 animate-in slide-in-from-right-8 duration-500">
            <div className="p-3 bg-teal-500/10 rounded-2xl w-fit text-teal-400">
              <User className="w-6 h-6" />
            </div>
            <h2 className="text-3xl font-sora font-bold">Preliminary Information</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Full Name</label>
                <input className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-4 focus:ring-1 focus:ring-teal-500 outline-none" placeholder="John Doe" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Contact Email</label>
                <input className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-4 focus:ring-1 focus:ring-teal-500 outline-none" placeholder="john@example.com" />
              </div>
            </div>
            <button onClick={nextStep} className="w-full py-4 bg-teal-500 text-slate-900 font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-teal-400">
              Next Step <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6 animate-in slide-in-from-right-8 duration-500">
            <div className="p-3 bg-teal-500/10 rounded-2xl w-fit text-teal-400">
              <Wallet className="w-6 h-6" />
            </div>
            <h2 className="text-3xl font-sora font-bold">Incident Details</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Transaction Hash / URL</label>
                <input className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-4 focus:ring-1 focus:ring-teal-500 outline-none" placeholder="0x..." />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Incident Type</label>
                <select className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-4 focus:ring-1 focus:ring-teal-500 outline-none appearance-none">
                  <option>Cryptocurrency Rugpull</option>
                  <option>Exchange Withdrawal Issue</option>
                  <option>Romance / Social Engineering</option>
                  <option>Identity Theft</option>
                </select>
              </div>
            </div>
            <div className="flex gap-4">
              <button onClick={prevStep} className="flex-1 py-4 glass font-bold rounded-xl">Back</button>
              <button onClick={nextStep} className="flex-[2] py-4 bg-teal-500 text-slate-900 font-bold rounded-xl">Next Step</button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6 animate-in slide-in-from-right-8 duration-500">
            <div className="p-3 bg-teal-500/10 rounded-2xl w-fit text-teal-400">
              <Shield className="w-6 h-6" />
            </div>
            <h2 className="text-3xl font-sora font-bold">Legal Affirmation</h2>
            <p className="text-slate-400 text-sm italic">
              "I certify that I am the rightful owner of the assets described, and I authorize Hackite to conduct open-source investigation into these transactions."
            </p>
            <div className="flex items-center gap-3 p-4 glass rounded-xl border-teal-500/20">
              <input type="checkbox" className="w-5 h-5 accent-teal-500" id="agree" />
              <label htmlFor="agree" className="text-xs font-bold uppercase tracking-widest cursor-pointer">I understand and agree to the ethics policy</label>
            </div>
            <div className="flex gap-4">
              <button onClick={prevStep} className="flex-1 py-4 glass font-bold rounded-xl">Back</button>
              <button onClick={() => setSubmitted(true)} className="flex-[2] py-4 bg-teal-500 text-slate-900 font-bold rounded-xl flex items-center justify-center gap-2">
                Submit Case <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default IntakeForm;
