
import React from 'react';
import { Linkedin, Mail, ShieldCheck } from 'lucide-react';

const TEAM = [
  {
    name: "Dr. Elena Vance",
    role: "Lead Blockchain Forensicist",
    bio: "Former financial crimes investigator with over 15 years experience in tracking illicit crypto flows.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80"
  },
  {
    name: "Marcus Thorne",
    role: "Cybersecurity Strategist",
    bio: "Specializes in identity restoration and SIM-swap mitigation for high-net-worth individuals.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80"
  },
  {
    name: "Sarah Chen",
    role: "OSINT Specialist",
    bio: "Expert in open-source intelligence and digital footprint analysis to unmask social engineering networks.",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=400&q=80"
  }
];

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-slate-900/20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          <div className="md:w-1/2 space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass border-teal-500/20 text-teal-400 text-xs font-semibold uppercase tracking-widest">
              <ShieldCheck className="w-4 h-4" />
              Human-Led Investigation
            </div>
            <h2 className="font-sora text-4xl md:text-5xl font-bold leading-tight">
              The Minds Behind <br />
              <span className="text-teal-400">Digital Justice.</span>
            </h2>
            <p className="text-slate-400 text-lg leading-relaxed">
              While our AI provides immediate analysis, our strength lies in our multidisciplinary team of real-world investigators. We don't just use tools; we understand the psychology of fraud.
            </p>
            <div className="space-y-4">
              <div className="flex items-start gap-4 p-4 glass rounded-2xl border-white/5">
                <div className="p-2 bg-teal-400/10 rounded-lg text-teal-400">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold">Ethical Framework</h4>
                  <p className="text-sm text-slate-500">We operate strictly within legal bounds, ensuring all evidence collected is admissible for official reports.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="md:w-1/2 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {TEAM.map((member, i) => (
              <div key={i} className={`glass p-4 rounded-3xl border-white/5 transition-all hover:border-teal-500/30 group ${i === 0 ? 'sm:row-span-2' : ''}`}>
                <div className="relative overflow-hidden rounded-2xl mb-4 h-48 sm:h-auto sm:aspect-[4/5]">
                  <img src={member.image} alt={member.name} className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-110 opacity-80" />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60"></div>
                </div>
                <h3 className="font-sora font-bold text-lg">{member.name}</h3>
                <p className="text-teal-400 text-xs font-bold uppercase tracking-wider mb-2">{member.role}</p>
                <p className="text-slate-500 text-xs leading-relaxed">{member.bio}</p>
                <div className="flex gap-2 mt-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Linkedin className="w-4 h-4 text-slate-400 hover:text-teal-400 cursor-pointer" />
                  <Mail className="w-4 h-4 text-slate-400 hover:text-teal-400 cursor-pointer" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
