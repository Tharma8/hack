
import React, { useEffect, useState } from 'react';
import { Globe, ShieldAlert, Zap } from 'lucide-react';

const LiveScamMap: React.FC = () => {
  const [threats, setThreats] = useState<{ x: number, y: number, id: number, type: string }[]>([]);
  
  useEffect(() => {
    const interval = setInterval(() => {
      const newThreat = {
        x: Math.random() * 80 + 10,
        y: Math.random() * 60 + 20,
        id: Date.now(),
        type: ['Phishing', 'Rugpull', 'Impersonation', 'SIM Swap'][Math.floor(Math.random() * 4)]
      };
      setThreats(prev => [...prev.slice(-5), newThreat]);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-24 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="glass rounded-[3rem] p-12 border-white/5 overflow-hidden min-h-[500px] flex flex-col md:flex-row items-center gap-12">
          
          <div className="md:w-1/3 space-y-6">
            <div className="p-3 bg-red-500/10 rounded-2xl w-fit text-red-400 border border-red-500/20">
              <Zap className="w-6 h-6 animate-pulse" />
            </div>
            <h2 className="font-sora text-3xl font-bold">Global Intelligence <br/><span className="text-slate-500 text-xl font-medium">Active Threat Pulse</span></h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Our network of nodes continuously monitors blockchain anomalies and domain registrations. These pings represent real-time pattern detections globally.
            </p>
            <div className="space-y-4 pt-4">
              {threats.map(t => (
                <div key={t.id} className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-slate-500 border-b border-white/5 pb-2 animate-in fade-in slide-in-from-left-4">
                  <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_5px_red]"></div> {t.type}</span>
                  <span className="text-slate-600">Detect @ {t.x.toFixed(0)}°N, {t.y.toFixed(0)}°W</span>
                </div>
              ))}
            </div>
          </div>

          <div className="md:w-2/3 relative h-[300px] md:h-[400px] w-full bg-slate-950/50 rounded-3xl border border-white/5 flex items-center justify-center">
            {/* Mock Map Background */}
            <div className="absolute inset-0 opacity-10">
              <svg viewBox="0 0 800 400" className="w-full h-full text-teal-400">
                 <path fill="currentColor" d="M150,100 Q200,80 250,120 T350,110 T450,130 T600,100 T700,120 L750,200 L700,300 L600,320 L450,300 L350,330 L250,300 L150,320 Z" />
                 <circle cx="200" cy="150" r="2" />
                 <circle cx="600" cy="180" r="2" />
                 <circle cx="400" cy="250" r="2" />
              </svg>
            </div>
            
            <Globe className="w-32 h-32 text-slate-800 opacity-20 animate-[spin_20s_linear_infinite]" />
            
            {/* Threat Pings */}
            {threats.map((t) => (
              <div 
                key={t.id} 
                className="absolute w-4 h-4 flex items-center justify-center"
                style={{ left: `${t.x}%`, top: `${t.y}%` }}
              >
                <div className="absolute w-full h-full rounded-full bg-red-500 animate-ping opacity-75"></div>
                <div className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_10px_red]"></div>
              </div>
            ))}

            <div className="absolute bottom-6 right-6 flex items-center gap-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest bg-slate-950/80 px-4 py-2 rounded-full border border-white/10">
              <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div> Investigation Live</div>
              <div className="flex items-center gap-2"><Globe className="w-3 h-3" /> Global Mesh active</div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default LiveScamMap;
