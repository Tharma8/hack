
import React, { useState } from 'react';
import { Search, ShieldAlert, Loader2, MessageCircle, ArrowRight, Zap, Target } from 'lucide-react';

const AddressScanner: React.FC = () => {
  const [address, setAddress] = useState('');
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<null | 'high' | 'critical'>(null);

  const handleScan = () => {
    if (!address) return;
    setScanning(true);
    setResult(null);
    setTimeout(() => {
      setScanning(false);
      setResult(Math.random() > 0.5 ? 'critical' : 'high');
    }, 2500);
  };

  const whatsappUrl = `https://wa.me/1234567890?text=${encodeURIComponent(`I just scanned address ${address} and it flagged high risk. I need a forensic deep dive.`)}`;

  return (
    <section className="py-24 relative">
      <div className="max-w-6xl mx-auto px-6">
        <div className="glass rounded-[3.5rem] p-12 border-teal-500/10 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/5 blur-[100px]" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/5 blur-[100px]" />

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8 relative z-10">
              <div className="p-3 bg-teal-500/10 rounded-2xl w-fit text-teal-400">
                <Target className="w-8 h-8" />
              </div>
              <h2 className="text-4xl md:text-5xl font-sora font-bold leading-tight">
                Instantly Scan for <br/><span className="text-teal-400">Malicious Nodes.</span>
              </h2>
              <p className="text-slate-400 text-lg">
                Enter a Bitcoin, Ethereum, or Solana address to check it against our Global Blacklist of known scam wallets, mixing services, and sanctioned entities.
              </p>
              
              <div className="relative group">
                <input 
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Paste wallet address (0x... or 1bc...)"
                  className="w-full bg-slate-950/80 border border-white/10 rounded-2xl py-6 px-8 text-white focus:ring-1 focus:ring-teal-500 outline-none transition-all placeholder:text-slate-700"
                />
                <button 
                  onClick={handleScan}
                  disabled={scanning || !address}
                  className="absolute right-3 top-3 bottom-3 px-8 bg-teal-500 rounded-xl text-slate-900 font-black flex items-center gap-2 hover:bg-teal-400 disabled:opacity-50 transition-all shadow-lg shadow-teal-500/20"
                >
                  {scanning ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Zap className="w-5 h-5" /> Run Forensic Scan</>}
                </button>
              </div>
            </div>

            <div className="relative flex items-center justify-center">
              {scanning ? (
                <div className="w-full aspect-square flex flex-col items-center justify-center space-y-6 animate-in fade-in duration-500">
                   <div className="relative">
                      <div className="w-48 h-48 rounded-full border-4 border-teal-500/10 animate-[spin_3s_linear_infinite]" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Search className="w-12 h-12 text-teal-400 animate-pulse" />
                      </div>
                   </div>
                   <p className="text-xs font-bold text-teal-400 uppercase tracking-[0.3em] animate-pulse">Scanning Global Mesh Network...</p>
                </div>
              ) : result ? (
                <div className="w-full p-10 glass bg-red-500/5 border-red-500/20 rounded-[2.5rem] space-y-8 animate-in zoom-in-95 duration-500 text-center">
                   <div className="w-20 h-20 rounded-full bg-red-500/10 flex items-center justify-center mx-auto text-red-500 border border-red-500/20">
                     <ShieldAlert className="w-10 h-10" />
                   </div>
                   <div className="space-y-2">
                     <h3 className="text-3xl font-sora font-bold text-red-400">Risk Level: {result === 'critical' ? 'CRITICAL' : 'HIGH'}</h3>
                     <p className="text-slate-400">Found 4 links to unauthorized mixing services in Seychelles and Estonia.</p>
                   </div>
                   <div className="pt-4 space-y-4">
                     <a 
                      href={whatsappUrl}
                      target="_blank"
                      className="w-full py-5 bg-teal-500 text-slate-900 font-black rounded-2xl flex items-center justify-center gap-3 hover:scale-105 transition-transform"
                     >
                       <MessageCircle className="w-6 h-6" /> Immediate Expert Intervention
                     </a>
                     <p className="text-[10px] text-slate-600 uppercase font-bold tracking-widest">Connect directly to our forensic team for asset freezing</p>
                   </div>
                </div>
              ) : (
                <div className="w-full aspect-square glass rounded-full border-white/5 flex items-center justify-center opacity-20">
                   <div className="text-center space-y-4">
                      <Search className="w-24 h-24 mx-auto text-slate-500" />
                      <p className="font-bold uppercase tracking-widest text-sm">System Ready</p>
                   </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AddressScanner;
