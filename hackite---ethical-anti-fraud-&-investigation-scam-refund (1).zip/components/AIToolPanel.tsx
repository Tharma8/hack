
import React, { useState, useEffect, useRef } from 'react';
import { analyzeScam } from '../services/gemini';
import { AnalysisResult, ScamSeverity, RedFlag, ActionStep } from '../types';
import { 
  AlertTriangle, 
  Loader2, 
  CheckCircle2, 
  Info, 
  ShieldAlert, 
  TrendingDown, 
  ChevronDown, 
  MessageSquareQuote,
  Shield,
  Phone,
  FileText,
  Landmark,
  Lock,
  Mail,
  RefreshCw,
  AlertCircle
} from 'lucide-react';

const Counter: React.FC<{ value: number; duration?: number }> = ({ value, duration = 1500 }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number | null = null;
    const endValue = value;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const easedProgress = 1 - Math.pow(1 - progress, 3);
      
      const nextCount = Math.floor(easedProgress * endValue);
      setCount(nextCount);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [value, duration]);

  return <span>{count}%</span>;
};

const AnimatedMeter: React.FC<{ 
  label: string; 
  value: number; 
  colorClass: string; 
  icon: React.ReactNode;
}> = ({ label, value, colorClass, icon }) => {
  const [width, setWidth] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setWidth(value), 100);
    return () => clearTimeout(timer);
  }, [value]);

  return (
    <div className="glass bg-slate-800/20 p-6 rounded-3xl border-white/5 relative overflow-hidden group">
      <div className={`absolute top-0 right-0 w-32 h-32 opacity-10 blur-2xl rounded-full -mr-10 -mt-10 transition-colors duration-1000 ${colorClass.split(' ')[0]}`}></div>
      
      <div className="flex justify-between items-center mb-5 relative z-10">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg bg-opacity-20 ${colorClass.split(' ')[0]} bg-current`}>
            {icon}
          </div>
          <span className="text-sm font-bold text-slate-300 uppercase tracking-widest">{label}</span>
        </div>
        <span className={`text-2xl font-sora font-bold ${colorClass}`}>
          <Counter value={value} />
        </span>
      </div>

      <div className="h-4 w-full bg-slate-900/80 rounded-full overflow-hidden border border-white/5 relative">
        <div 
          className={`h-full transition-all duration-[1500ms] ease-[cubic-bezier(0.34,1.56,0.64,1)] relative overflow-hidden ${colorClass.split(' ')[0]} bg-current`}
          style={{ width: `${width}%` }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full animate-[shimmer_2s_infinite]"></div>
        </div>
      </div>
    </div>
  );
};

const RedFlagItem: React.FC<{ flag: RedFlag; index: number }> = ({ flag, index }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <div 
      className={`group cursor-pointer rounded-2xl border border-white/5 bg-white/[0.02] transition-all duration-300 hover:bg-white/[0.04] ${expanded ? 'border-red-500/30 ring-1 ring-red-500/20' : ''}`}
      onClick={() => setExpanded(!expanded)}
    >
      <div className="flex items-center gap-4 p-4">
        <span className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center text-red-400 shrink-0 font-bold text-xs group-hover:bg-red-500/20 transition-colors">
          {index + 1}
        </span>
        <div className="flex-1 flex justify-between items-center">
          <span className="text-sm font-semibold text-slate-200">{flag.title}</span>
          <ChevronDown className={`w-4 h-4 text-slate-500 transition-transform duration-300 ${expanded ? 'rotate-180' : ''}`} />
        </div>
      </div>
      <div className={`overflow-hidden transition-all duration-300 ease-in-out ${expanded ? 'max-h-40' : 'max-h-0'}`}>
        <div className="px-16 pb-4 text-xs text-slate-400 leading-relaxed border-t border-white/5 pt-3">
          {flag.explanation}
        </div>
      </div>
    </div>
  );
};

const ActionIcon: React.FC<{ type: string }> = ({ type }) => {
  switch (type) {
    case 'shield': return <Shield className="w-3 h-3" />;
    case 'phone': return <Phone className="w-3 h-3" />;
    case 'file': return <FileText className="w-3 h-3" />;
    case 'bank': return <Landmark className="w-3 h-3" />;
    case 'lock': return <Lock className="w-3 h-3" />;
    case 'mail': return <Mail className="w-3 h-3" />;
    case 'refresh': return <RefreshCw className="w-3 h-3" />;
    case 'alert': return <AlertCircle className="w-3 h-3" />;
    default: return <CheckCircle2 className="w-3 h-3" />;
  }
};

const AIToolPanel: React.FC = () => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  const handleAnalyze = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setResult(null);
    setShowDetails(false);
    
    try {
      const analysis = await analyzeScam(input);
      setResult(analysis);
      setTimeout(() => setShowDetails(true), 600);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getSeverityStyles = (severity: ScamSeverity) => {
    switch (severity) {
      case ScamSeverity.CRITICAL: return 'text-red-500 border-red-500/20 bg-red-500/10';
      case ScamSeverity.HIGH: return 'text-orange-500 border-orange-500/20 bg-orange-500/10';
      case ScamSeverity.MEDIUM: return 'text-yellow-500 border-yellow-500/20 bg-yellow-500/10';
      default: return 'text-teal-400 border-teal-500/20 bg-teal-500/10';
    }
  };

  return (
    <section id="tools" className="py-24 relative overflow-hidden">
      <div className="max-w-4xl mx-auto px-6">
        <div className="glass rounded-[40px] p-8 md:p-12 border-white/10 relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/5 blur-[100px] rounded-full -mr-20 -mt-20"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/5 blur-[100px] rounded-full -ml-20 -mb-20"></div>
          
          <div className="relative z-10 text-center space-y-4 mb-12">
            <h2 className="font-sora text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-400">
              AI Fraud Intelligence
            </h2>
            <p className="text-slate-400 max-w-lg mx-auto leading-relaxed">
              Our advanced neural network analyzes conversation patterns, transaction footprints, and social engineering triggers in seconds.
            </p>
          </div>

          <div className="relative mb-12 group">
            <div className="absolute -inset-1 bg-gradient-to-r from-teal-500/20 to-blue-500/20 rounded-3xl blur opacity-0 group-focus-within:opacity-100 transition duration-500"></div>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Describe the suspicious activity or paste a message..."
              className="relative w-full h-44 bg-slate-950/50 border border-white/10 rounded-3xl p-8 text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-teal-500/50 transition-all text-lg leading-relaxed shadow-inner"
            />
            <button
              onClick={handleAnalyze}
              disabled={loading || !input}
              className="absolute bottom-6 right-6 px-10 py-4 rounded-2xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-black flex items-center gap-3 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-xl shadow-teal-500/20 hover:scale-105 active:scale-95"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <ShieldAlert className="w-5 h-5" />
                  <span>Execute Analysis</span>
                </>
              )}
            </button>
          </div>

          {result && (
            <div className="space-y-10 animate-in fade-in slide-in-from-bottom-10 duration-700 fill-mode-both">
              <div className="flex justify-center">
                <div className={`px-6 py-2 rounded-full border font-black text-xs uppercase tracking-[0.3em] ${getSeverityStyles(result.severity)} shadow-lg`}>
                  Threat Level: {result.severity}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <AnimatedMeter 
                  label="Scam Probability" 
                  value={result.probabilityScore} 
                  colorClass={result.probabilityScore > 70 ? 'text-red-400 fill-red-400' : 'text-teal-400 fill-teal-400'} 
                  icon={<AlertTriangle className="w-5 h-5" />}
                />
                <AnimatedMeter 
                  label="Recovery Potential" 
                  value={result.recoveryLikelihood} 
                  colorClass="text-blue-400 fill-blue-400" 
                  icon={<TrendingDown className="w-5 h-5 rotate-180" />}
                />
              </div>

              <div className="relative animate-in zoom-in-95 duration-700 delay-300 fill-mode-both">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-teal-500/20 via-transparent to-blue-500/20 rounded-[2.5rem] blur-xl opacity-50"></div>
                <div className="relative p-10 glass bg-slate-900/60 rounded-[2.5rem] border border-white/10 overflow-hidden">
                  <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-teal-500 to-blue-500"></div>
                  
                  <div className="flex flex-col md:flex-row gap-8 items-start">
                    <div className="shrink-0 p-4 bg-teal-400/10 rounded-2xl border border-teal-400/20 shadow-[0_0_20px_rgba(45,212,191,0.1)]">
                      <MessageSquareQuote className="w-8 h-8 text-teal-400" />
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="font-sora text-xl font-bold text-white flex items-center gap-3">
                        Investigator Executive Summary
                        <span className="h-px flex-1 bg-white/10 hidden md:block"></span>
                      </h3>
                      <p className="text-lg text-slate-200 leading-relaxed font-medium">
                        {result.explanation}
                      </p>
                      <div className="flex items-center gap-4 text-xs font-bold text-slate-500 uppercase tracking-widest pt-2">
                        <div className="flex items-center gap-2">
                          <ShieldAlert className="w-4 h-4 text-teal-500/60" /> Verified Intelligence
                        </div>
                        <span className="w-1 h-1 rounded-full bg-slate-700"></span>
                        <div>Generated at {new Date().toLocaleTimeString()}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {showDetails && (
                <div className="grid md:grid-cols-2 gap-10 animate-in fade-in slide-in-from-bottom-4 duration-1000">
                  <div className="glass bg-slate-900/30 p-8 rounded-[32px] border-white/5 space-y-6">
                    <h4 className="flex items-center gap-3 font-bold text-red-400 uppercase tracking-widest text-xs">
                      <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                      Intelligence Red Flags
                    </h4>
                    <div className="space-y-3">
                      {result.redFlags.map((flag, i) => (
                        <RedFlagItem key={i} flag={flag} index={i} />
                      ))}
                    </div>
                  </div>

                  <div className="glass bg-slate-900/30 p-8 rounded-[32px] border-white/5 space-y-6">
                    <h4 className="flex items-center gap-3 font-bold text-teal-400 uppercase tracking-widest text-xs">
                      <div className="w-2 h-2 rounded-full bg-teal-400 animate-pulse"></div>
                      Counter-Fraud Strategy
                    </h4>
                    <ul className="space-y-4">
                      {result.actionPlan.map((step, i) => (
                        <li key={i} className="text-sm text-slate-300 flex items-start gap-4 leading-relaxed group">
                          <span className="w-6 h-6 rounded-lg bg-teal-500/10 flex items-center justify-center text-teal-400 shrink-0 group-hover:bg-teal-500/20 transition-colors">
                            <ActionIcon type={step.iconType} />
                          </span> 
                          {step.text}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default AIToolPanel;
