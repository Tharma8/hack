
import React from 'react';
import { ExternalLink, TrendingUp, ShieldAlert, History } from 'lucide-react';

const STUDIES = [
  {
    title: "Exchange Breach Recovery",
    tag: "Crypto Theft",
    stat: "$240k Recovered",
    description: "Successfully traced funds through 4 intermediate 'mixing' wallets to identify a KYC-verified off-ramp, leading to a successful asset freeze.",
    image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "SIM-Swap Fraud Mitigation",
    tag: "Identity Theft",
    stat: "Identity Restored",
    description: "Rapid response to a high-value SIM swap attack. Coordinated with major carriers to lock accounts and secure secondary banking credentials within 45 minutes.",
    image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80"
  }
];

const CaseStudies: React.FC = () => {
  return (
    <section id="cases" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-end mb-16">
          <div className="space-y-4">
            <h2 className="font-sora text-4xl font-bold">Investigative Success</h2>
            <p className="text-slate-400 max-w-xl">
              Real results achieved through methodological tracing and persistence. 
              Names and specific dates are omitted for victim privacy.
            </p>
          </div>
          <button className="hidden md:flex items-center gap-2 text-teal-400 font-bold hover:underline">
            View All Reports <ExternalLink className="w-4 h-4" />
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {STUDIES.map((study, i) => (
            <div key={i} className="group relative glass rounded-[2.5rem] overflow-hidden border-white/5 hover:border-teal-500/20 transition-all">
              <div className="aspect-video overflow-hidden">
                <img src={study.image} alt={study.title} className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700" />
              </div>
              <div className="p-8 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="px-3 py-1 rounded-full bg-teal-400/10 text-teal-400 text-[10px] font-bold uppercase tracking-widest border border-teal-500/10">
                    {study.tag}
                  </span>
                  <div className="flex items-center gap-2 text-teal-400 font-bold text-sm">
                    <TrendingUp className="w-4 h-4" /> {study.stat}
                  </div>
                </div>
                <h3 className="font-sora text-2xl font-bold text-white">{study.title}</h3>
                <p className="text-slate-400 leading-relaxed italic text-sm">
                  "{study.description}"
                </p>
                <div className="pt-4 flex items-center gap-6 text-[10px] text-slate-500 font-bold uppercase tracking-widest border-t border-white/5">
                  <div className="flex items-center gap-2"><History className="w-4 h-4" /> Duration: 14 Days</div>
                  <div className="flex items-center gap-2"><ShieldAlert className="w-4 h-4" /> Priority: Critical</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CaseStudies;
