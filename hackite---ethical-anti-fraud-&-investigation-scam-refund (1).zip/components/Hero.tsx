
import React, { useState, useEffect } from 'react';
import { ChevronRight, ArrowRight, MessageCircle, Zap, ShieldCheck } from 'lucide-react';

interface HeroProps {
  onStartCase: () => void;
}

const HireNowButton: React.FC = () => {
  const [textIndex, setTextIndex] = useState(0);
  const phrases = ["Hire Now", "Start Recovery", "Talk to Expert", "Trace Assets"];
  
  useEffect(() => {
    const interval = setInterval(() => {
      setTextIndex((prev) => (prev + 1) % phrases.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  const whatsappUrl = `https://wa.me/1234567890?text=${encodeURIComponent("I need immediate forensic assistance for my case. Please connect me with a Lead Investigator.")}`;

  return (
    <a 
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="group relative px-8 py-4 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 text-slate-900 font-black flex items-center gap-3 transition-all transform hover:scale-105 shadow-[0_0_30px_rgba(45,212,191,0.4)] overflow-hidden"
    >
      <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
      <MessageCircle className="w-5 h-5 relative z-10" />
      <span className="relative z-10 inline-block min-w-[120px] text-center transition-all duration-500 animate-in fade-in slide-in-from-bottom-2" key={textIndex}>
        {phrases[textIndex]}
      </span>
    </a>
  );
};

const Hero: React.FC<HeroProps> = ({ onStartCase }) => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-teal-500/10 blur-[120px] rounded-full"></div>
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-blue-500/10 blur-[120px] rounded-full"></div>

      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
        <div className="relative z-10 space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-1000">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass border-teal-500/20 text-teal-400 text-xs font-semibold uppercase tracking-widest">
            <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse"></span>
            Professional Bitcoin & Asset Recovery
          </div>
          <h1 className="font-sora text-5xl md:text-7xl font-bold leading-tight">
            Recover Your <br />
            <span className="text-teal-400">Digital Assets.</span>
          </h1>
          <p className="text-xl text-slate-400 max-w-lg leading-relaxed">
            Specialized in high-stakes Bitcoin forensics, Ethereum tracing, and unmasking cyber-fraud networks. We provide the evidence needed to reclaim what is yours.
          </p>
          
          <div className="flex flex-wrap gap-4">
            <HireNowButton />
            <button 
              onClick={onStartCase}
              className="px-8 py-4 rounded-xl glass hover:bg-white/10 font-bold transition-all border border-white/10 flex items-center gap-2"
            >
              Start Case Intake <ArrowRight className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-6 pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-yellow-500/10 rounded-lg text-yellow-500">
                <Zap className="w-5 h-5" />
              </div>
              <div className="text-sm">
                <div className="font-bold text-white">BTC Recovery</div>
                <div className="text-xs text-slate-500">UTXO Tracing</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-teal-400/10 rounded-lg text-teal-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="text-sm">
                <div className="font-bold text-white">Ethical Lead</div>
                <div className="text-xs text-slate-500">Forensic Reports</div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4 text-sm text-slate-500 pt-4">
            <div className="flex -space-x-2">
              {[1,2,3,4].map(i => (
                <img key={i} src={`https://picsum.photos/seed/user${i}/40/40`} className="w-8 h-8 rounded-full border-2 border-slate-900" alt="User" />
              ))}
            </div>
            <span>Trusted by 850+ recovery clients</span>
          </div>
        </div>

        <div className="relative hidden md:block animate-in fade-in zoom-in duration-1000">
          <div className="relative z-10 glass rounded-[3rem] p-4 overflow-hidden shadow-2xl border-white/5">
            <img 
              src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80" 
              className="rounded-[2.5rem] w-full h-[550px] object-cover opacity-80" 
              alt="Cyber Investigation Lab" 
            />
            {/* Overlay Indicators */}
            <div className="absolute top-12 left-12 glass p-6 rounded-3xl border-teal-500/20 animate-float shadow-2xl bg-slate-950/40">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-teal-400/20 rounded-xl">
                  <ShieldCheck className="w-6 h-6 text-teal-400" />
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold">Node Status</div>
                  <div className="text-lg font-bold text-white">Tracing #14 Active</div>
                </div>
              </div>
            </div>

            <div className="absolute bottom-12 right-12 glass p-4 rounded-2xl border-white/10 bg-slate-950/60 backdrop-blur-xl">
              <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-2">Recent Success</div>
              <div className="text-teal-400 font-black text-xl">2.5 BTC Recovered</div>
              <div className="text-[10px] text-slate-400">Transaction ID Verified</div>
            </div>
          </div>
          {/* Decorative Elements */}
          <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-teal-500/5 blur-3xl rounded-full"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
