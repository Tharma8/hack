
import React from 'react';
import { ShieldCheck, CheckCircle2, Award, Zap, ArrowRight, MessageCircle } from 'lucide-react';

const GuaranteePage: React.FC<{ onStartCase: () => void }> = ({ onStartCase }) => {
  return (
    <div className="pt-28 pb-20 px-6 min-h-screen bg-[#0a0a0c]">
      <div className="max-w-4xl mx-auto space-y-20">
        <header className="text-center space-y-6 animate-in fade-in slide-in-from-bottom-8 duration-700">
          <div className="p-4 bg-teal-400/10 rounded-full w-fit mx-auto text-teal-400 border border-teal-500/20 shadow-[0_0_30px_rgba(45,212,191,0.1)]">
            <Award className="w-12 h-12" />
          </div>
          <h1 className="text-5xl md:text-7xl font-sora font-bold leading-tight">
            Our 100% <br/><span className="text-teal-400">Success Promise.</span>
          </h1>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed">
            We don't believe in paying for failure. Our investigation model is built on accountability, precision, and a zero-risk commitment to our clients.
          </p>
        </header>

        <div className="grid gap-8">
          {[
            {
              title: "Full Asset Tracing Guarantee",
              desc: "If our forensic nodes cannot successfully identify the final off-ramp or KYC-entity associated with your lost assets, you are entitled to a 100% refund of all forensic fees.",
              icon: <ShieldCheck className="w-8 h-8 text-teal-400" />
            },
            {
              title: "Zero Retainer Model",
              desc: "For high-value cases ($50k+), we operate on a performance basis. We invest our own investigative resources up-front. We only succeed when your assets are identified.",
              icon: <Zap className="w-8 h-8 text-teal-400" />
            },
            {
              title: "Evidence Admissibility Warranty",
              desc: "We guarantee that every report we produce meets the standards of international law enforcement agencies (Interpol, FBI, Europol). If a bank rejects our forensic data, we rewrite it for free.",
              icon: <CheckCircle2 className="w-8 h-8 text-teal-400" />
            }
          ].map((item, i) => (
            <div key={i} className="glass p-10 rounded-[3rem] border-white/5 flex flex-col md:flex-row gap-8 items-center transition-all hover:border-teal-500/20 group">
              <div className="shrink-0 p-6 bg-slate-900 rounded-[2rem] border border-white/5 group-hover:bg-teal-400/10 transition-colors">
                {item.icon}
              </div>
              <div className="space-y-4 text-center md:text-left">
                <h3 className="text-2xl font-sora font-bold text-white">{item.title}</h3>
                <p className="text-slate-400 leading-relaxed text-lg">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="glass p-12 rounded-[3rem] border-teal-500/20 bg-teal-500/[0.03] text-center space-y-8 relative overflow-hidden">
           <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/5 blur-[100px]" />
           <h2 className="text-3xl font-sora font-bold">Ready to recover your peace of mind?</h2>
           <p className="text-slate-400 max-w-xl mx-auto">
             Join the 850+ victims who have used our forensic reports to successfully challenge fraudulent transactions and restore their digital legacy.
           </p>
           <div className="flex flex-col sm:flex-row justify-center gap-4">
             <button 
               onClick={onStartCase}
               className="px-12 py-5 bg-teal-500 text-slate-900 font-black rounded-2xl flex items-center justify-center gap-3 hover:scale-105 transition-transform"
             >
               Start New Intake <ArrowRight className="w-5 h-5" />
             </button>
             <button className="px-12 py-5 glass font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-white/10 transition-all">
               <MessageCircle className="w-5 h-5" /> Talk to an Agent
             </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default GuaranteePage;
