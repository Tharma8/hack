
import React from 'react';
import { MessageCircle, ShieldAlert } from 'lucide-react';

const WhatsAppButton: React.FC = () => {
  const phoneNumber = "1234567890"; // Example
  const message = "URGENT: I need a professional forensic investigator to help me with a scam recovery.";
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  return (
    <div className="fixed bottom-8 right-8 z-[100] flex flex-col items-end gap-3 group">
      <div className="bg-slate-900 glass text-white px-5 py-3 rounded-2xl border-teal-500/30 font-bold text-sm shadow-2xl opacity-0 group-hover:opacity-100 transition-all translate-y-2 group-hover:translate-y-0 flex items-center gap-2">
        <ShieldAlert className="w-4 h-4 text-teal-400" />
        Connect with Live Investigator
      </div>
      <a 
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-16 h-16 rounded-full bg-teal-500 flex items-center justify-center text-slate-900 shadow-[0_0_30px_rgba(45,212,191,0.5)] animate-pulse-teal transition-all hover:scale-110 active:scale-95 group"
      >
        <MessageCircle className="w-8 h-8 group-hover:rotate-12 transition-transform" />
      </a>
    </div>
  );
};

export default WhatsAppButton;
