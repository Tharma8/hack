
import React from 'react';
import { Zap, ShieldAlert, Globe, ArrowRight } from 'lucide-react';

const ALERTS = [
  {
    title: "New 'Phantom Drainer' script detected in Wild",
    type: "Tech Alert",
    date: "2 hours ago",
    description: "Our bots detected a new malicious script being injected into popular DApp clones. High risk for Solana users.",
    image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=400&q=80"
  },
  {
    title: "Global Romance Scam Network Dismantled",
    type: "Case Report",
    date: "1 day ago",
    description: "Hackite provided the OSINT packets that led to the identification of a large-scale hub in SE Asia.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80"
  }
];

const IntelligenceHub: React.FC = () => {
  return (
    <div className="pt-28 pb-20 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-16">
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-red-500 text-xs font-bold uppercase tracking-widest">
            <Zap className="w-4 h-4" /> Live Threat Intel Feed
          </div>
          <h1 className="text-5xl font-sora font-bold">Stay Ahead of <br/><span className="text-teal-400">the Fraudsters.</span></h1>
        </div>
        <p className="text-slate-400 max-w-sm text-sm">
          Real-time updates from our global investigative nodes. We monitor the dark web so you don't have to.
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {ALERTS.map((alert, i) => (
            <div key={i} className="glass p-8 rounded-[3rem] border-white/5 flex flex-col md:flex-row gap-8 hover:border-teal-500/20 transition-all group cursor-pointer">
              <div className="md:w-1/3 aspect-video md:aspect-square rounded-2xl overflow-hidden shrink-0 border border-white/10">
                <img src={alert.image} className="w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-700" alt="News" />
              </div>
              <div className="flex flex-col justify-center space-y-4">
                <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest">
                  <span className="text-teal-400">{alert.type}</span>
                  <span className="text-slate-500">{alert.date}</span>
                </div>
                <h3 className="text-2xl font-bold leading-tight group-hover:text-teal-400 transition-colors">{alert.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{alert.description}</p>
                <div className="pt-2 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-slate-300">
                  Read Full Intelligence <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="space-y-8">
          <div className="glass p-8 rounded-[2rem] border-red-500/20 bg-red-500/[0.02]">
            <div className="flex items-center gap-3 text-red-500 mb-6">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
              <h3 className="font-bold uppercase tracking-widest text-xs">Critical Alerts</h3>
            </div>
            <div className="space-y-4">
              {[
                "New Ledger Phishing App on AppStore",
                "Solana Node Vulnerability (Exploited)",
                "Telegram Support Impersonators (Global)"
              ].map((text, i) => (
                <div key={i} className="p-4 bg-slate-900/50 rounded-xl border border-white/5 flex gap-3 items-center group cursor-pointer hover:bg-red-500/5 transition-colors">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  <p className="text-xs font-bold text-slate-300 group-hover:text-white">{text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass p-8 rounded-[2rem] border-white/5 overflow-hidden relative">
            <Globe className="absolute -bottom-10 -right-10 w-40 h-40 text-teal-400 opacity-5" />
            <h3 className="font-bold mb-4">Node Network</h3>
            <p className="text-xs text-slate-500 leading-relaxed mb-6">
              Our mesh network of 400+ forensic nodes ensures real-time detection across all major EVM and non-EVM chains.
            </p>
            <div className="flex items-center gap-4">
               <div className="flex -space-x-3">
                 {[1,2,3].map(i => <div key={i} className="w-8 h-8 rounded-full border-2 border-slate-900 bg-slate-800" />)}
               </div>
               <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Active nodes in 12 regions</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IntelligenceHub;
