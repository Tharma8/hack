
import React, { useState } from 'react';
import { FileText, Plus, Trash2, Download } from 'lucide-react';
import { EvidenceItem } from '../types';

const EvidenceToolkit: React.FC = () => {
  const [items, setItems] = useState<EvidenceItem[]>([]);
  const [newItem, setNewItem] = useState({ type: '', date: '', description: '', amount: '' });

  const addItem = () => {
    if (!newItem.description || !newItem.date) return;
    setItems([...items, { ...newItem, id: Date.now().toString() }]);
    setNewItem({ type: '', date: '', description: '', amount: '' });
  };

  const removeItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  return (
    <section id="toolkit" className="py-24 bg-slate-900/50">
      <div className="max-w-5xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h2 className="font-sora text-3xl font-bold mb-2">Evidence Timeline Builder</h2>
            <p className="text-slate-400">Organize your case details for bank disputes or police reports.</p>
          </div>
          <button className="flex items-center gap-2 px-6 py-3 rounded-xl glass border-teal-500/20 text-teal-400 hover:bg-teal-400/10 transition-all font-bold">
            <Download className="w-5 h-5" /> Export PDF Report
          </button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 glass p-6 rounded-3xl h-fit border-white/5 sticky top-24">
            <h3 className="font-bold mb-6 flex items-center gap-2">
              <Plus className="w-5 h-5 text-teal-400" /> Add Event
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest block mb-2">Event Date</label>
                <input 
                  type="date" 
                  value={newItem.date}
                  onChange={e => setNewItem({...newItem, date: e.target.value})}
                  className="w-full bg-slate-900/50 border border-white/10 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-teal-500" 
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest block mb-2">Type</label>
                <select 
                   value={newItem.type}
                   onChange={e => setNewItem({...newItem, type: e.target.value})}
                   className="w-full bg-slate-900/50 border border-white/10 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-teal-500"
                >
                  <option value="">Select Type</option>
                  <option value="Transaction">Transaction</option>
                  <option value="Communication">Communication</option>
                  <option value="Account Access">Account Access</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest block mb-2">Description</label>
                <textarea 
                  value={newItem.description}
                  onChange={e => setNewItem({...newItem, description: e.target.value})}
                  className="w-full bg-slate-900/50 border border-white/10 rounded-xl px-4 py-2 text-sm h-24 resize-none focus:outline-none focus:ring-1 focus:ring-teal-500" 
                  placeholder="Details of the interaction..."
                />
              </div>
              <button 
                onClick={addItem}
                className="w-full py-3 rounded-xl bg-teal-500 text-slate-900 font-bold hover:bg-teal-400 transition-colors"
              >
                Add to Timeline
              </button>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-4">
            {items.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-slate-600 space-y-4 glass rounded-3xl border-dashed border-2 border-white/5">
                <FileText className="w-12 h-12 opacity-20" />
                <p>Your evidence timeline is currently empty.</p>
              </div>
            ) : (
              items.sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map((item) => (
                <div key={item.id} className="glass p-6 rounded-2xl border-white/5 flex gap-6 group hover:border-teal-500/30 transition-colors">
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center font-bold text-xs text-teal-400 border border-teal-500/20">
                      {new Date(item.date).toLocaleDateString(undefined, { day: '2-digit', month: 'short' })}
                    </div>
                    <div className="flex-1 w-px bg-slate-800 my-2"></div>
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="flex justify-between items-start">
                      <span className="px-2 py-0.5 rounded bg-teal-400/10 text-teal-400 text-[10px] font-bold uppercase tracking-wider">
                        {item.type}
                      </span>
                      <button 
                        onClick={() => removeItem(item.id)}
                        className="text-slate-600 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-slate-300">{item.description}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default EvidenceToolkit;
