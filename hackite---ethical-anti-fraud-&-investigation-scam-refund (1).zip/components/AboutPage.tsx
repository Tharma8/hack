
import React from 'react';
import { Shield, Globe, Cpu, Users, ArrowRight } from 'lucide-react';
import AboutSection from './AboutSection';

const AboutPage: React.FC = () => {
  return (
    <div className="pt-28 bg-[#0a0a0c]">
      <div className="max-w-7xl mx-auto px-6 space-y-24">
        {/* Mission Hero */}
        <section className="text-center space-y-8 py-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass border-teal-500/20 text-teal-400 text-xs font-semibold uppercase tracking-widest">
            <Shield className="w-4 h-4" /> The Hackite Mission
          </div>
          <h1 className="text-6xl md:text-8xl font-sora font-bold">
            Defending the <br/><span className="text-teal-400">Digital Frontier.</span>
          </h1>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto leading-relaxed">
            In an era of decentralized finance and borderless fraud, traditional law enforcement is often overwhelmed. Hackite was founded to provide victims with the high-end forensic tools previously only available to state actors.
          </p>
        </section>

        {/* Core Values Bento */}
        <div className="grid md:grid-cols-3 gap-8">
          <div className="glass p-10 rounded-[3rem] border-white/5 space-y-6">
            <div className="p-4 bg-blue-500/10 rounded-2xl w-fit text-blue-400">
              <Globe className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-bold">Borderless Forensic Mesh</h3>
            <p className="text-slate-500 text-sm leading-relaxed">Our network of 400+ investigation nodes spans 12 jurisdictions, allowing us to track assets even when they cross complex international borders.</p>
          </div>
          <div className="glass p-10 rounded-[3rem] border-white/5 space-y-6">
            <div className="p-4 bg-teal-400/10 rounded-2xl w-fit text-teal-400">
              <Cpu className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-bold">AI-Powered Patterning</h3>
            <p className="text-slate-500 text-sm leading-relaxed">We use neural networks to recognize "Scam Signatures" across millions of transactions, identifying new threats before they become widespread.</p>
          </div>
          <div className="glass p-10 rounded-[3rem] border-white/5 space-y-6">
            <div className="p-4 bg-purple-500/10 rounded-2xl w-fit text-purple-400">
              <Users className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-bold">Human-Centric Ethics</h3>
            <p className="text-slate-500 text-sm leading-relaxed">Technology is just a tool. Our real power comes from our investigators' empathy and deep understanding of the human element in fraud.</p>
          </div>
        </div>

        {/* Reuse the existing Team section inside the full page */}
        <div className="py-20">
          <AboutSection />
        </div>

        {/* Global Impact Section */}
        <section className="py-24 glass rounded-[4rem] border-white/5 overflow-hidden relative mb-20">
           <div className="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none">
             <img src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&q=80" className="w-full h-full object-cover" alt="Globe" />
           </div>
           <div className="max-w-4xl mx-auto text-center space-y-8 relative z-10 px-6">
             <h2 className="text-4xl font-sora font-bold">A Global Effort for Digital Justice.</h2>
             <p className="text-slate-400 text-lg">
               Since 2019, Hackite has helped thousands of individuals recover over $120M in lost digital assets. We coordinate daily with local and international authorities to bring transparency to the shadow economy.
             </p>
             <button className="px-10 py-5 bg-white text-slate-900 font-bold rounded-2xl flex items-center justify-center gap-3 mx-auto hover:bg-slate-200 transition-colors">
               Read our 2024 Transparency Report <ArrowRight className="w-5 h-5" />
             </button>
           </div>
        </section>
      </div>
    </div>
  );
};

export default AboutPage;
