
import React from 'react';
import { ExternalLink, Landmark, Globe, ShieldAlert } from 'lucide-react';

const RESOURCES = [
  {
    name: "FBI IC3",
    region: "USA",
    description: "Internet Crime Complaint Center for reporting digital fraud.",
    url: "https://www.ic3.gov/"
  },
  {
    name: "Action Fraud",
    region: "UK",
    description: "The UK's national reporting center for fraud and cybercrime.",
    url: "https://www.actionfraud.police.uk/"
  },
  {
    name: "ACORN",
    region: "Australia",
    description: "Australian Cybercrime Online Reporting Network.",
    url: "https://www.cyber.gov.au/acsc/report"
  },
  {
    name: "Europol",
    region: "EU",
    description: "European Union Agency for Law Enforcement Cooperation.",
    url: "https://www.europol.europa.eu/report-a-crime"
  }
];

const Resources: React.FC = () => {
  return (
    <section id="resources" className="py-24 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <h2 className="font-sora text-3xl font-bold mb-12">Official Reporting Channels</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {RESOURCES.map((res, i) => (
            <a 
              key={i} 
              href={res.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="glass p-6 rounded-2xl border-white/5 hover:border-teal-500/30 transition-all text-left group"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="p-2 bg-slate-800 rounded-lg text-slate-400 group-hover:text-teal-400">
                  <Globe className="w-5 h-5" />
                </div>
                <ExternalLink className="w-4 h-4 text-slate-700 group-hover:text-teal-400" />
              </div>
              <h4 className="font-bold text-white mb-1">{res.name}</h4>
              <p className="text-[10px] text-teal-400 uppercase tracking-widest font-bold mb-2">{res.region}</p>
              <p className="text-xs text-slate-500 leading-relaxed">{res.description}</p>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Resources;
