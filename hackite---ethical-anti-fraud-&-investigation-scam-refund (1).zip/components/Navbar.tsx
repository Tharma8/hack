
import React from 'react';
import { Shield } from 'lucide-react';

interface NavbarProps {
  onNavigate: (page: any) => void;
  currentPage: string;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentPage }) => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5 px-6 py-4">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={() => onNavigate('home')}
        >
          <Shield className="w-8 h-8 text-teal-400 group-hover:scale-110 transition-transform" />
          <span className="font-sora text-2xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-teal-400">
            HACKITE
          </span>
        </div>
        <div className="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-300">
          <button 
            onClick={() => onNavigate('home')} 
            className={`hover:text-teal-400 transition-colors ${currentPage === 'home' ? 'text-teal-400' : ''}`}
          >
            Home
          </button>
          <button 
            onClick={() => onNavigate('about')} 
            className={`hover:text-teal-400 transition-colors ${currentPage === 'about' ? 'text-teal-400' : ''}`}
          >
            About Hackite
          </button>
          <button 
            onClick={() => onNavigate('guarantee')} 
            className={`hover:text-teal-400 transition-colors ${currentPage === 'guarantee' ? 'text-teal-400 font-bold' : ''}`}
          >
            Guarantee
          </button>
          <button 
            onClick={() => onNavigate('intel')} 
            className={`hover:text-teal-400 transition-colors ${currentPage === 'intel' ? 'text-teal-400' : ''}`}
          >
            Intelligence Hub
          </button>
          <button 
            onClick={() => onNavigate('portal')}
            className={`px-5 py-2 rounded-full border border-teal-500/50 text-teal-400 hover:bg-teal-400/10 transition-all ${currentPage === 'portal' ? 'bg-teal-400/10' : ''}`}
          >
            Secure Case Portal
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
