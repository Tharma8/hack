
import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

const FAQS = [
  {
    q: "Can you 'hack back' and take my money from the scammer?",
    a: "No. Hackite operates ethically and legally. We provide tracing, evidence, and professional guidance for official recovery routes. Illegal 'hacking' services are often scams themselves."
  },
  {
    q: "What is a recovery likelihood score based on?",
    a: "Our AI and investigators analyze several factors: the age of the scam, whether funds have been moved to a KYC-verified exchange, the jurisdiction of the perpetrator, and the amount of evidence available."
  },
  {
    q: "Will you report my case to the police for me?",
    a: "We provide you with a professional Evidence Timeline and PDF Report that is ready for submission to law enforcement (like FBI IC3 or Action Fraud). We can guide you on the submission process, but you must be the one to file the report."
  },
  {
    q: "How long does a blockchain investigation usually take?",
    a: "Initial automated analysis is instant. A deep forensic audit typically takes between 3 to 14 business days depending on the complexity of the wallet network and mixing services used."
  }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" className="py-24 bg-slate-900/10">
      <div className="max-w-3xl mx-auto px-6">
        <div className="text-center mb-16 space-y-4">
          <div className="p-3 bg-teal-400/10 rounded-2xl w-fit mx-auto text-teal-400 border border-teal-500/20 mb-4">
            <HelpCircle className="w-6 h-6" />
          </div>
          <h2 className="font-sora text-3xl font-bold">Frequently Asked Questions</h2>
          <p className="text-slate-400">Clear answers for complex situations.</p>
        </div>

        <div className="space-y-4">
          {FAQS.map((faq, i) => (
            <div key={i} className="glass rounded-2xl border-white/5 overflow-hidden group">
              <button 
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full p-6 text-left flex justify-between items-center hover:bg-white/5 transition-colors"
              >
                <span className="font-bold text-slate-200">{faq.q}</span>
                <ChevronDown className={`w-5 h-5 text-slate-500 transition-transform ${openIndex === i ? 'rotate-180' : ''}`} />
              </button>
              <div className={`overflow-hidden transition-all duration-300 ${openIndex === i ? 'max-h-96' : 'max-h-0'}`}>
                <div className="p-6 pt-0 text-slate-400 text-sm leading-relaxed border-t border-white/5 mt-2">
                  {faq.a}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
