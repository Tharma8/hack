
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, ScamSeverity } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeScam = async (input: string): Promise<AnalysisResult> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the following scam-related input and provide a structured risk assessment. 
    Input: "${input}"
    Focus on: identifying red flags with detailed forensic-style explanations, recovery probability, and a precise action plan.
    For the action plan, assign one of these icon types to each step: shield, phone, file, bank, lock, mail, alert, refresh.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          probabilityScore: { type: Type.NUMBER, description: "0-100 percentage of how likely this is a scam." },
          recoveryLikelihood: { type: Type.NUMBER, description: "0-100 percentage of successful fund or account recovery." },
          severity: { type: Type.STRING, description: "Severity: LOW, MEDIUM, HIGH, or CRITICAL." },
          redFlags: { 
            type: Type.ARRAY, 
            items: { 
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                explanation: { type: Type.STRING }
              },
              required: ["title", "explanation"]
            } 
          },
          actionPlan: { 
            type: Type.ARRAY, 
            items: { 
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING, description: "The descriptive text of the action step." },
                iconType: { type: Type.STRING, description: "One of: shield, phone, file, bank, lock, mail, alert, refresh" }
              },
              required: ["text", "iconType"]
            } 
          },
          explanation: { type: Type.STRING, description: "Overall summary of the case." }
        },
        required: ["probabilityScore", "recoveryLikelihood", "severity", "redFlags", "actionPlan", "explanation"]
      }
    }
  });

  try {
    const text = response.text;
    if (!text) {
      throw new Error("AI returned an empty response.");
    }
    return JSON.parse(text.trim()) as AnalysisResult;
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    throw new Error("Could not analyze case data.");
  }
};
